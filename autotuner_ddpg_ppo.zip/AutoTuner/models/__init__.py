# -*- coding: utf-8 -*-


from ddpg import DDPG
from ppo import PPO
#import replay_memory
from ppo import Memory
from ppo_from_ddpg import PPO_FROM_DDPG

#self.action_var = torch.full((action_dim,), action_std * action_std).to(device)
__all__ = ["PPO","DDPG", "DQN", "replay_memory","Memory","PPO_FROM_DDPG"]

