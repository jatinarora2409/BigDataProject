# -*- coding: utf-8 -*-

"""
description: MySQL Database Configurations
"""

instance_config = {
    'mysql1': {
        'host': '192.168.0.11',
        'user': 'root',
        'passwd': '12345678',
        'port': 3306,
        'database': 'data',
        'memory': 34359738368
    },
    'mysql2': {
        'host': '172.31.62.4',
        'user': 'root',
        'passwd': '123456',
        'port': 3306,
        'database': 'sbtest',
        'memory': 8589934592
    },
    'mysql3': {
        'host': '172.31.74.126',
        'user': 'root',
        'passwd': '123456',
        'port': 3306,
        'database': 'sbtest',
        'memory': 8589934592
    },
    'mysql4': {
        'host': '172.31.75.95',
        'user': 'root',
        'passwd': '123456',
        'port': 3306,
        'database': 'sbtest',
        'memory': 8589934592
    }
}



