#!/usr/bin/env bash

nohup sudo python server.py >> server.log &