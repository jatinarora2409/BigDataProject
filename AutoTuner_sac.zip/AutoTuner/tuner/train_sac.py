# -*- coding: utf-8 -*-
"""
Train the model
"""

import os
import sys
import utils
import pickle
import argparse
sys.path.append('../')
import numpy as np
import environment
from agent import Agent


def generate_knob(action, method):
    if method == 'sac':
        return environment.gen_continuous(action)
    else:
        raise NotImplementedError('Not Implemented')


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('--tencent', action='store_true', help='Use Tencent Server')
    parser.add_argument('--params', type=str, default='', help='Load existing parameters')
    parser.add_argument('--workload', type=str, default='read', help='Workload type [`read`, `write`, `readwrite`]')
    parser.add_argument('--instance', type=str, default='mysql1', help='Choose MySQL Instance')
    parser.add_argument('--method', type=str, default='ddpg', help='Choose Algorithm to solve [`ddpg`,`dqn`,`ppo`]')
    parser.add_argument('--memory', type=str, default='', help='add replay memory')
    parser.add_argument('--noisy', action='store_true', help='use noisy linear layer')
    parser.add_argument('--other_knob', type=int, default=0, help='Number of other knobs')
    parser.add_argument('--batch_size', type=int, default=16, help='Training Batch Size')
    parser.add_argument('--epoches', type=int, default=5000000, help='Training Epoches')
    parser.add_argument('--benchmark', type=str, default='sysbench', help='[sysbench, tpcc]')
    parser.add_argument('--metric_num', type=int, default=63, help='metric nums')
    parser.add_argument('--default_knobs', type=int, default=6, help='default knobs')
    opt = parser.parse_args()

    # Create Environment
    if opt.tencent:
        env = environment.TencentServer(
            wk_type=opt.workload,
            instance_name=opt.instance,
            method=opt.benchmark,
            num_metric=opt.metric_num,
            num_other_knobs=opt.other_knob)
    else:
        env = environment.Server(wk_type=opt.workload, instance_name=opt.instance)

    # Build models
    # ddpg_opt = dict()
    # ddpg_opt['tau'] = 0.00001
    # ddpg_opt['alr'] = 0.00001
    # ddpg_opt['clr'] = 0.00001
    # ddpg_opt['model'] = opt.params
    n_states = opt.metric_num
    gamma = 0.9
    memory_size = 100000
    num_actions = opt.default_knobs + opt.other_knob
    # ddpg_opt['gamma'] = gamma
    # ddpg_opt['batch_size'] = opt.batch_size
    # ddpg_opt['memory_size'] = memory_size

    # model = models.DDPG(
    #     n_states=n_states,
    #     n_actions=num_actions,
    #     opt=ddpg_opt,
    #     mean_var_path='mean_var.pkl',
    #     ouprocess=not opt.noisy
    # )
    agent = Agent(input_dims=n_states, env=env,
            n_actions=num_actions)

    if not os.path.exists('log'):
        os.mkdir('log')

    if not os.path.exists('save_memory'):
        os.mkdir('save_memory')

    if not os.path.exists('save_knobs'):
        os.mkdir('save_knobs')

    if not os.path.exists('save_state_actions'):
        os.mkdir('save_state_actions')

    if not os.path.exists('model_params'):
        os.mkdir('model_params')

    expr_name = 'train_{}_{}'.format(opt.method, str(utils.get_timestamp()))

    logger = utils.Logger(
        name=opt.method,
        log_file='log/{}.log'.format(expr_name)
    )

    if opt.other_knob != 0:
        logger.warn('USE Other Knobs')
    print("abc1")
    filename = 'inverted_pendulum.png'

    figure_file = 'plots/' + filename
    current_knob = environment.get_init_knobs()

    # decay rate
    sigma_decay_rate = 0.9
    step_counter = 0
    train_step = 0
    accumulate_loss = [0, 0]

    fine_state_actions = []

    # TODO:
    # if len(opt.memory) > 0:
    #     model.replay_memory.load_memory(opt.memory)
    #     print("Load Memory: {}".format(len(model.replay_memory)))
    best_score = float('-inf') 
    score_history = []
    load_checkpoint = True

    if load_checkpoint:
        agent.load_models()
    
    print("before for loop")
    step_counter = 0    
    for episode in xrange(opt.epoches):
        current_state, initial_metrics = env.initialize()
        print("Current state:" , current_state, "Initial_metrics : ", initial_metrics)
	done = False
        score = 0
        logger.info("\n[Env initialized][Metric tps: {} lat: {} qps: {}]".format( initial_metrics[0], initial_metrics[1], initial_metrics[2]))
        while not done and score >= -50:
            state = current_state
            action = agent.choose_action(state)
            current_knob = generate_knob(action, 'sac')
            logger.info("[sac] Action: {}".format(action))

            reward, state_, done, score, metrics, restart_time = env.step(current_knob)
            logger.info(
                "\n[{}][Episode: {}][Metric tps:{} lat:{} qps:{}]Reward: {} Score: {} Done: {}".format(
                    opt.method, episode, metrics[0], metrics[1], metrics[2], reward, score, done
                ))

            next_state = state_
            agent.remember(state, action, reward, next_state, done)
            if not load_checkpoint:
                agent.learn()
            current_state = next_state
	    step_counter+=1
	    if step_counter % 5 == 0:
		agent.save_models()
        
        score_history.append(score)
        avg_score = np.mean(score_history[-100:])

        if avg_score > best_score:
	    best_score = avg_score
            if not load_checkpoint:
                agent.save_models()

        logger.info("\n[Episode: {}][Score: {}][Avg_score: {}]".format(episode, score , avg_score))

    if not load_checkpoint:
        x = [i+1 for i in range(opt.epoches)]
        utils.plot_learning_curve(x, score_history, figure_file)
           
           

            
